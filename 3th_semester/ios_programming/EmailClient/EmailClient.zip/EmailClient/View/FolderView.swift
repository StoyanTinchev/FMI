import Foundation

import SwiftUI

struct FolderView: View {
    @Binding var folder: Folder
    var emailFolders: EmailFolders

    var body: some View {
        List {
            ForEach(folder.emails, id: \.id) { email in
                NavigationLink(destination: EmailView(email: email,
                                                      delete: {
                    emailFolders.deleteEmail(email, from: folder)
                })) {
                    Text(email.subject)
                }
                .swipeActions {
                    Button(role: .destructive) {
                        emailFolders.deleteEmail(email, from: folder)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
        }
        .navigationTitle(folder.name)
    }
}
