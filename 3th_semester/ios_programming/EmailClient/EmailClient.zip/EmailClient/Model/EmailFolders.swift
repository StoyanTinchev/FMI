import Foundation

class EmailFolders: ObservableObject {
    @Published var folders: [Folder]

    init() {
        self.folders = Folder.mocks
    }

    func deleteEmail(_ email: Email, from folder: Folder) {
        if let folderIndex = folders.firstIndex(where: { $0.name == folder.name }) {
            var modifiedFolder = folders[folderIndex]
            modifiedFolder.deleteEmail(email)

            if modifiedFolder.name != "Trash" {
                if let trashIndex = folders.firstIndex(where: { $0.name == "Trash" }) {
                    folders[trashIndex].emails.append(email)
                }
            }

            folders[folderIndex] = modifiedFolder
        }
    }
}
