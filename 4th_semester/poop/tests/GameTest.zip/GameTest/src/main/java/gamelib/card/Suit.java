package gamelib.card;

public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES,
}
