module com.fmi.gametest {
    requires javafx.controls;
    requires javafx.fxml;


    opens gametest to javafx.fxml;
    exports gametest;
}