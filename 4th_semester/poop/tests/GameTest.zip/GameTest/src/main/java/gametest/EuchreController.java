package gametest;

import gamelib.EuchreGame;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class EuchreController {
    @FXML
    private TextArea textArea;
    @FXML
    private Label scoreLabel;

    private final EuchreGame euchreGame = new EuchreGame();

    @FXML
    protected void dealHand(ActionEvent event) {
        euchreGame.dealHand();
        textArea.appendText(euchreGame.printCards() + "\n");
        updateScore();
    }

    @FXML
    protected void hasJackQueenKing(ActionEvent event) {
        textArea.appendText(euchreGame.hasJackQueenKing() + "\n");
    }

    @FXML
    protected void hasTwoTrumps(ActionEvent event) {
        textArea.appendText(euchreGame.hasTwoTrumps() + "\n");
    }

    @FXML
    protected void endGame(ActionEvent event) {
        System.exit(0);
    }

    private void updateScore() {
        int score = euchreGame.countHandStrength();
        scoreLabel.setText("Точки: " + score);
    }
}
