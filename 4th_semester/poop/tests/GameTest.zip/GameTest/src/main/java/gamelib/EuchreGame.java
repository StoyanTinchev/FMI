package gamelib;

import gamelib.card.Card;
import gamelib.card.Face;
import gamelib.card.Suit;

import java.util.Random;

public class EuchreGame {
    public static Face[] faces = new Face[]{Face.NINE, Face.TEN, Face.JACK, Face.QUEEN, Face.KING, Face.ACE};
    public static Suit[] suits = new Suit[]{Suit.CLUBS, Suit.DIAMONDS, Suit.HEARTS, Suit.SPADES};
    Card[] cards; // масив от всички карти в тестето от карти
    Card[] hand; // текущо изтеглена ръка от 5 карти
    final Suit TRUMP; // константа на всяка отделна игра
    private final Random random; // генератор на случайни числа
    private int usedCards; // брой карти изтеглени текущо от cards

    //    Добавете конструктор по подразбиране, където cards се инициализира с всички 24
//    карти (четири цвята, всеки с по 6 различни сили), TRUMP (цвят избран за Коз) е
//    произволно избран елемент на suits, а останалите с подразбиращи се стойности да са
//    в съответствие с поставените задачи по- долу.
    public EuchreGame() {
        cards = new Card[24];
        hand = new Card[5];
        random = new Random();
        usedCards = 0;
        int index = 0;
        for (Suit suit : suits) {
            for (Face face : faces) {
                cards[index++] = new Card(face.toString(), suit.toString());
            }
        }
        TRUMP = suits[random.nextInt(suits.length)];
    }

    //    Добавете метод
//    public void shuffleCards(),
//    който разбърква елементите на масива cards в случаен ред и инициализира на
//    нула usedCards .
    public void shuffleCards() {
        for (int i = 0; i < cards.length; i++) {
            int randomIndex = random.nextInt(cards.length);
            Card temp = cards[i];
            cards[i] = cards[randomIndex];
            cards[randomIndex] = temp;
        }
        usedCards = 0;
    }

    //    Добавете метод
//    String printCards(),
//    който връща текстовото описание на картите в масива hand. Картите да са по три
//    на ред (последният ред има по- малко) и текстовото им описание да е разделено
//    със запетаи, без запетая в края на реда. На отделен ред да се изведе цвета на
//    текущия Коз (вижте примера в края на текста).
    public String printCards() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hand.length; i++) {
            sb.append(hand[i]);
            if (i % 3 == 2) {
                sb.append("\n");
            } else {
                sb.append(", ");
            }
        }
        sb.append("\nTrump: ").append(TRUMP);
        return sb.toString();
    }

    //    Добавете метод
//    boolean dealHand( ),
//    който връща true или false в зависимост дали са останали или не карти за
//    изтегляне в cards. Ако има карти за изтегляне, те се записват последователно в
//    hand. В hand се записват 5 карти или по- малко, ако толкова са останали в cards.
//    0 1 2 3 4
//    5 6 7 8 9
//    10 11 12 13 14
//    15 16 17 18 19
//    20 21 22 23
    public boolean dealHand() {
        if (usedCards + 1 > cards.length) {
            return false;
        }
        for (int i = 0; i < 5 && usedCards < cards.length; i++) {
            hand[i] = cards[usedCards++];
        }
        return true;
    }

    //    Добавете метод
//    int countHandStrength(),
//    връща точките на картите на hand (сумират се произведенията на броят на
//    картите от всяка сила по стойността на силата, както е представена в Заданието).
    public int countHandStrength() {
        int points = 0;
        for (Card card : hand) {
            points += card.getPoints();
        }
        return points;
    }

    //    Добавете метод
//    boolean hasJackQueenKing (),
//    който връща true или false в зависимост дали измежду елементите на hand има
//    KING, QUEEN и JACK от произволен цвят (Suit).
    public boolean hasJackQueenKing() {
        boolean hasJack = false;
        boolean hasQueen = false;
        boolean hasKing = false;
        for (Card card : hand) {
            if (card.getFace().equals(Face.JACK.toString())) {
                hasJack = true;
            } else if (card.getFace().equals(Face.QUEEN.toString())) {
                hasQueen = true;
            } else if (card.getFace().equals(Face.KING.toString())) {
                hasKing = true;
            }
        }
        return hasJack && hasQueen && hasKing;
    }

    //    Добавете метод
//    boolean hasTwoTrumps (),
//    който връща true или false в зависимост дали измежду елементите на hand има
//    двойка карти от избрания цвят за Коз (TRUMP).
    public boolean hasTwoTrumps() {
        int count = 0;
        for (Card card : hand) {
            if (card.getSuit().equals(TRUMP.toString())) {
                count++;
            }
        }
        return count >= 2;
    }
}
